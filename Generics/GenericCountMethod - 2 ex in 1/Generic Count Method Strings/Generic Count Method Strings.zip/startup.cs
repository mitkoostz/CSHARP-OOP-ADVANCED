﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Count_Method_Strings
{
    public class startup
    {
        public static void Main()
        {
            List<string> list = new List<string>();
            var n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var text = Console.ReadLine();
                list.Add(text);
            }

            var lastInput = Console.ReadLine();
            

            Console.WriteLine(Box.Compare(list, lastInput));
        }
    }
}
