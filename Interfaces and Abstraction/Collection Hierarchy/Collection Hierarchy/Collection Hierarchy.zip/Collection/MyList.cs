﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_Hierarchy.Collection
{
    using Interfaces;
    public class MyList : Collection, IMyList
    {
        public int count
        {
            get
            {
                return base.Elements.Count;
            }
        }

        public int Add(string element)
        {
            base.Elements.Insert(0, element);
            return 0;
        }

        public string Remove()
        {
            string element = base.Elements[0];
            base.Elements.RemoveAt(0);
            return element;
        }
    }
}
